=== HƯỚNG DẪN CÀI ĐẶT TIỆN ÍCH URL LOCK SHIELD VÀO TRÌNH DUYỆT ===

Tiện ích này đã được sửa lỗi: Nút Enable (Bật/Tắt chặn) không hoạt động.
Giờ đây:
- Khi chưa đặt mật khẩu: Bạn có thể Bật/Tắt chặn mượt mà không bị treo hay kẹt.
- Khi đã đặt mật khẩu: Tiện ích yêu cầu xác thực mật khẩu chuẩn xác trước khi cho phép tắt/bật hoặc sửa danh sách chặn.
- Hỗ trợ chặn YouTube toàn diện (cả trang chủ, video, shorts, SPA navigation), Facebook, TikTok,...

CÁC BƯỚC CÀI ĐẶT:
1. Giải nén file zip này ra một thư mục trên máy tính (ví dụ: C:\url-lock-shield hoặc Desktop\url-lock-shield).
2. Mở trình duyệt Chrome / Edge / Brave / Cốc Cốc.
3. Nhập vào thanh địa chỉ: chrome://extensions (với Edge là edge://extensions).
4. Bật công tắc "Chế độ dành cho nhà phát triển" (Developer mode) ở góc trên bên phải.
5. Bấm vào nút "Tải tiện ích đã giải nén" (Load unpacked).
6. Chọn thư mục vừa giải nén ở Bước 1.
7. Biểu tượng URL Lock Shield sẽ xuất hiện trên thanh tiện ích của bạn!
