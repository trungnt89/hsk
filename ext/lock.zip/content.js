// content.js - Chạy ở cấp độ DOM (document_start) để chặn đứng các trang web SPA như YouTube ngay lập tức
(function() {
  function isUrlBlockedInContent(urlStr, blacklist) {
    try {
      if (!urlStr || typeof urlStr !== 'string') return false;
      const url = new URL(urlStr);
      if (url.protocol === "chrome-extension:" || url.protocol === "chrome:") return false;

      const host = url.hostname.toLowerCase();
      const pathname = url.pathname.toLowerCase();
      const fullUrl = url.href.toLowerCase();

      return (blacklist || []).some(blocked => {
        let cleanBlocked = (blocked || "").trim().toLowerCase();
        if (!cleanBlocked) return false;
        cleanBlocked = cleanBlocked.replace(/^(https?:\/\/)?(www\.)?/, '');
        const cleanNoSlash = cleanBlocked.replace(/\/+$/, '');

        // Hỗ trợ triệt để domain YouTube & youtu.be
        if (cleanNoSlash === 'youtube.com' || cleanNoSlash === 'm.youtube.com') {
          if (host === 'youtube.com' || host.endsWith('.youtube.com') || host === 'youtu.be' || host.endsWith('.youtu.be')) {
            return true;
          }
        }

        try {
          const blockedUrl = new URL("http://" + cleanBlocked);
          const blockedHost = blockedUrl.hostname;
          const blockedPath = blockedUrl.pathname;
          const blockedSearch = blockedUrl.search;

          const hostMatch = host === blockedHost || host.endsWith("." + blockedHost);
          if (!hostMatch) return false;

          if ((blockedPath === '/' || blockedPath === '') && !blockedSearch) {
            return true;
          }

          const visitedPathClean = pathname.replace(/\/+$/, '');
          const blockedPathClean = blockedPath.replace(/\/+$/, '');
          const pathMatch = visitedPathClean === blockedPathClean || visitedPathClean.startsWith(blockedPathClean + "/");
          if (!pathMatch) return false;

          if (blockedSearch) {
            const visitedParams = new URLSearchParams(url.search);
            const blockedParams = new URLSearchParams(blockedSearch);
            for (const [key, value] of blockedParams.entries()) {
              if (visitedParams.get(key) !== value) return false;
            }
            return true;
          }
          return true;
        } catch (err) {
          return fullUrl.includes(cleanNoSlash);
        }
      });
    } catch (e) {
      return false;
    }
  }

  function enforceBlock() {
    chrome.storage.local.get(["blacklist", "isEnabled"], (res) => {
      const isEnabled = res.isEnabled !== false;
      const blacklist = res.blacklist || [];
      const currentUrl = window.location.href;

      if (isEnabled && isUrlBlockedInContent(currentUrl, blacklist)) {
        try {
          window.stop(); // Ngăn trình duyệt tải thêm tài nguyên
        } catch (e) {}

        const blockedPageUrl = chrome.runtime.getURL("blocked.html") + "?url=" + encodeURIComponent(currentUrl);
        window.location.replace(blockedPageUrl);
      }
    });
  }

  // Chạy ngay khi file được inject vào DOM
  enforceBlock();

  // Bắt các sự kiện chuyển video của YouTube SPA & HTML5 History API
  window.addEventListener('yt-navigate-finish', enforceBlock);
  window.addEventListener('yt-page-data-updated', enforceBlock);
  window.addEventListener('popstate', enforceBlock);
})();