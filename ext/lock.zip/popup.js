// URL Lock Shield - popup.js (ĐÃ SỬA LỖI NÚT ENABLE)
document.addEventListener('DOMContentLoaded', async () => {
  const headerLockBadge = document.getElementById('header-lock-badge');
  const lockStatusBadge = document.getElementById('lock-status-badge');
  const navSettingsBtn = document.getElementById('nav-settings-btn');
  const quickLockBtn = document.getElementById('quick-lock-btn');
  const quickLockText = document.getElementById('quick-lock-text');
  const backToMainBtn = document.getElementById('back-to-main-btn');

  const tabMain = document.getElementById('tab-main');
  const tabSettings = document.getElementById('tab-settings');

  const shieldToggle = document.getElementById('shield-toggle');
  const shieldStatusText = document.getElementById('shield-status-text');
  const lockBanner = document.getElementById('lock-banner');
  const triggerUnlockBtn = document.getElementById('trigger-unlock-btn');
  const addInput = document.getElementById('add-input');
  const addBtn = document.getElementById('add-btn');
  const blacklistContainer = document.getElementById('blacklist-container');
  const blacklistCount = document.getElementById('blacklist-count');
  const importFile = document.getElementById('import-file');
  const exportListBtn = document.getElementById('export-list-btn');
  const logsContainer = document.getElementById('logs-container');
  const clearLogsBtn = document.getElementById('clear-logs-btn');

  const changePasswordForm = document.getElementById('change-password-form');
  const groupCurrentPwd = document.getElementById('group-current-pwd');
  const inputCurrentPwd = document.getElementById('input-current-pwd');
  const inputNewPwd = document.getElementById('input-new-pwd');
  const inputConfirmPwd = document.getElementById('input-confirm-pwd');
  const inputPwdHint = document.getElementById('input-pwd-hint');
  const labelNewPwd = document.getElementById('label-new-pwd');
  const savePasswordBtn = document.getElementById('save-password-btn');
  const autoLockSelect = document.getElementById('auto-lock-select');
  const settingsLockNowBtn = document.getElementById('settings-lock-now-btn');

  const unlockModal = document.getElementById('unlock-modal');
  const modalTitleText = document.getElementById('modal-title-text');
  const modalDescText = document.getElementById('modal-desc-text');
  const modalPwdInput = document.getElementById('modal-pwd-input');
  const togglePwdVisBtn = document.getElementById('toggle-pwd-vis-btn');
  const eyeOpenSvg = document.getElementById('eye-open-svg');
  const eyeClosedSvg = document.getElementById('eye-closed-svg');
  const modalHintBox = document.getElementById('modal-hint-box');
  const modalHintText = document.getElementById('modal-hint-text');
  const modalErrorMsg = document.getElementById('modal-error-msg');
  const modalCancelBtn = document.getElementById('modal-cancel-btn');
  const modalSubmitBtn = document.getElementById('modal-submit-btn');

  let isUnlocked = false;
  let pendingAction = null;

  async function hashPassword(password) {
    if (!password) return '';
    const enc = new TextEncoder();
    const data = enc.encode("url_lock_shield_salt_" + password);
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  // Khôi phục trạng thái mở khóa trong phiên làm việc
  const sessionUnlocked = sessionStorage.getItem('url_shield_session_unlocked');
  if (sessionUnlocked === 'true') {
    isUnlocked = true;
  }

  function updateLockStateUI(hasPassword) {
    if (!hasPassword) {
      document.body.className = 'unlocked-state';
      lockStatusBadge.textContent = 'CHƯA CÀI MẬT KHẨU';
      quickLockText.textContent = 'Cài mã';
      lockBanner.style.display = 'flex';
      const bannerSpan = lockBanner.querySelector('.lock-banner-left span');
      if (bannerSpan) bannerSpan.textContent = 'Chưa đặt mật khẩu bảo vệ cài đặt';
      triggerUnlockBtn.textContent = 'Thiết lập ngay';
      return;
    }

    if (isUnlocked) {
      document.body.className = 'unlocked-state';
      lockStatusBadge.textContent = 'ĐÃ MỞ KHÓA';
      quickLockText.textContent = 'Khóa lại';
      lockBanner.style.display = 'none';
    } else {
      document.body.className = 'locked-state';
      lockStatusBadge.textContent = 'ĐÃ KHÓA BẢO VỆ';
      quickLockText.textContent = 'Mở khóa';
      lockBanner.style.display = 'flex';
      const bannerSpan = lockBanner.querySelector('.lock-banner-left span');
      if (bannerSpan) bannerSpan.textContent = 'Cài đặt đang được khóa bằng mật khẩu';
      triggerUnlockBtn.textContent = 'Mở khóa';
    }
  }

  // Yêu cầu xác thực mật khẩu.
  // ĐẶC BIỆT: Nếu CHƯA CÓ MẬT KHẨU -> Cho phép thực hiện trực tiếp (KHÔNG CHẶN NỮA)!
  function requirePassword(actionCallback, reason = "thao tác này") {
    chrome.storage.local.get(['masterPasswordHash', 'passwordHint'], (res) => {
      const hasPassword = Boolean(res.masterPasswordHash);
      
      // FIX CỐT LÕI: Nếu chưa đặt mật khẩu, cho phép thao tác luôn!
      if (!hasPassword || isUnlocked) {
        if (actionCallback) actionCallback();
        return;
      }

      // Đã có mật khẩu và đang bị khóa -> Hiển thị Modal mở khóa
      pendingAction = actionCallback;
      modalTitleText.textContent = 'XÁC THỰC MẬT KHẨU';
      modalDescText.textContent = `Vui lòng nhập mật khẩu quản trị để ${reason}.`;
      modalPwdInput.value = '';
      modalErrorMsg.classList.add('hidden');

      if (res.passwordHint) {
        modalHintText.textContent = res.passwordHint;
        modalHintBox.classList.remove('hidden');
      } else {
        modalHintBox.classList.add('hidden');
      }

      unlockModal.classList.add('show');
      setTimeout(() => modalPwdInput.focus(), 100);
    });
  }

  function switchTab(tabName) {
    if (tabName === 'settings') {
      tabMain.classList.remove('active');
      tabSettings.classList.add('active');
    } else {
      tabSettings.classList.remove('active');
      tabMain.classList.add('active');
    }
  }

  function renderData() {
    chrome.storage.local.get([
      'blacklist', 'isEnabled', 'blockLogs', 'masterPasswordHash', 'passwordHint', 'autoLockSetting'
    ], (res) => {
      const hasPassword = Boolean(res.masterPasswordHash);
      const isEnabled = res.isEnabled !== false;
      const blacklist = res.blacklist || [];
      const blockLogs = res.blockLogs || [];

      updateLockStateUI(hasPassword);

      // Cập nhật trạng thái nút toggle gạt
      shieldToggle.checked = isEnabled;
      if (isEnabled) {
        shieldStatusText.textContent = "ĐANG HOẠT ĐỘNG";
        shieldStatusText.className = "status-active";
      } else {
        shieldStatusText.textContent = "ĐÃ TẮT BẢO VỆ";
        shieldStatusText.className = "status-inactive";
      }

      // Cập nhật danh sách chặn
      blacklistCount.textContent = blacklist.length;
      blacklistContainer.innerHTML = '';
      if (blacklist.length === 0) {
        blacklistContainer.innerHTML = '<div class="empty-state">Chưa có liên kết nào bị chặn.</div>';
      } else {
        blacklist.forEach((url, index) => {
          const item = document.createElement('div');
          item.className = 'whitelist-item';
          item.innerHTML = `
            <span class="url-text" title="${url}">${url}</span>
            <button class="delete-btn" data-index="${index}" title="Xóa khỏi danh sách chặn">
              <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
          `;
          blacklistContainer.appendChild(item);
        });
      }

      // Cập nhật nhật ký chặn
      logsContainer.innerHTML = '';
      if (blockLogs.length === 0) {
        logsContainer.innerHTML = '<div class="empty-state">Chưa chặn lượt truy cập nào.</div>';
      } else {
        blockLogs.slice(0, 15).forEach(log => {
          const logItem = document.createElement('div');
          logItem.className = 'log-item';
          let displayUrl = log.url;
          try {
            const tempUrl = new URL(log.url);
            displayUrl = tempUrl.hostname + (tempUrl.pathname && tempUrl.pathname !== '/' ? tempUrl.pathname : '') + tempUrl.search;
          } catch (e) {}
          logItem.innerHTML = `<div class="log-url" title="${log.url}">${displayUrl}</div><div class="log-time">${log.time || ''}</div>`;
          logsContainer.appendChild(logItem);
        });
      }

      // Giao diện cài đặt mật khẩu
      if (hasPassword) {
        groupCurrentPwd.style.display = 'block';
        labelNewPwd.textContent = 'Mật khẩu mới (Nếu muốn đổi):';
        savePasswordBtn.textContent = 'Cập nhật mật khẩu';
        inputPwdHint.value = res.passwordHint || '';
      } else {
        groupCurrentPwd.style.display = 'none';
        labelNewPwd.textContent = 'Tạo mật khẩu mới:';
        savePasswordBtn.textContent = 'Thiết lập mật khẩu bảo vệ';
        inputPwdHint.value = '';
      }

      if (res.autoLockSetting) autoLockSelect.value = res.autoLockSetting;
    });
  }

  // FIX NÚT GẠT ENABLE: Xử lý sự kiện click chuẩn xác, kiểm tra mật khẩu mượt mà
  shieldToggle.addEventListener('change', (e) => {
    const targetState = shieldToggle.checked;
    
    // Đảo tạm thời về trạng thái cũ để đợi xác thực nếu đang bị khóa
    chrome.storage.local.get(['masterPasswordHash'], (res) => {
      const hasPassword = Boolean(res.masterPasswordHash);
      if (hasPassword && !isUnlocked) {
        // Đang bị khóa: Hoàn lại vị trí nút gạt và yêu cầu nhập mật khẩu
        shieldToggle.checked = !targetState;
        requirePassword(() => {
          // Khi nhập đúng mật khẩu, bật/tắt chính xác sang targetState
          chrome.storage.local.set({ isEnabled: targetState }, () => {
            renderData();
          });
        }, targetState ? 'bật lại tính năng chặn' : 'tắt tạm thời lá chắn bảo vệ');
      } else {
        // Chưa đặt mật khẩu HOẶC đã mở khóa: Áp dụng ngay lập tức!
        chrome.storage.local.set({ isEnabled: targetState }, () => {
          renderData();
        });
      }
    });
  });

  navSettingsBtn.addEventListener('click', () => {
    chrome.storage.local.get(['masterPasswordHash'], (res) => {
      if (!res.masterPasswordHash) {
        switchTab('settings');
        return;
      }
      requirePassword(() => switchTab('settings'), 'mở Cài đặt hệ thống');
    });
  });

  backToMainBtn.addEventListener('click', () => switchTab('main'));

  quickLockBtn.addEventListener('click', () => {
    chrome.storage.local.get(['masterPasswordHash'], (res) => {
      if (!res.masterPasswordHash) {
        switchTab('settings');
        return;
      }
      if (isUnlocked) {
        isUnlocked = false;
        sessionStorage.removeItem('url_shield_session_unlocked');
        updateLockStateUI(true);
        if (tabSettings.classList.contains('active')) switchTab('main');
      } else {
        requirePassword(null, 'mở khóa các tính năng');
      }
    });
  });

  settingsLockNowBtn.addEventListener('click', () => {
    isUnlocked = false;
    sessionStorage.removeItem('url_shield_session_unlocked');
    updateLockStateUI(true);
    switchTab('main');
  });

  triggerUnlockBtn.addEventListener('click', () => {
    chrome.storage.local.get(['masterPasswordHash'], (res) => {
      if (!res.masterPasswordHash) switchTab('settings');
      else requirePassword(null, 'quản lý danh sách chặn & cài đặt');
    });
  });

  async function submitUnlockPassword() {
    const inputPwd = modalPwdInput.value.trim();
    if (!inputPwd) {
      modalErrorMsg.textContent = 'Vui lòng nhập mật khẩu!';
      modalErrorMsg.classList.remove('hidden');
      return;
    }

    const inputHash = await hashPassword(inputPwd);
    chrome.storage.local.get(['masterPasswordHash'], (res) => {
      if (res.masterPasswordHash === inputHash) {
        isUnlocked = true;
        sessionStorage.setItem('url_shield_session_unlocked', 'true');
        unlockModal.classList.remove('show');
        updateLockStateUI(true);
        if (pendingAction) {
          const action = pendingAction;
          pendingAction = null;
          action();
        }
      } else {
        modalErrorMsg.textContent = 'Mật khẩu không chính xác! Vui lòng thử lại.';
        modalErrorMsg.classList.remove('hidden');
        modalPwdInput.value = '';
        modalPwdInput.focus();
      }
    });
  }

  modalSubmitBtn.addEventListener('click', submitUnlockPassword);
  modalPwdInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') submitUnlockPassword();
  });
  modalCancelBtn.addEventListener('click', () => {
    unlockModal.classList.remove('show');
    pendingAction = null;
    renderData();
  });

  togglePwdVisBtn.addEventListener('click', () => {
    if (modalPwdInput.type === 'password') {
      modalPwdInput.type = 'text';
      eyeOpenSvg.classList.add('hidden');
      eyeClosedSvg.classList.remove('hidden');
    } else {
      modalPwdInput.type = 'password';
      eyeOpenSvg.classList.remove('hidden');
      eyeClosedSvg.classList.add('hidden');
    }
  });

  changePasswordForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const currentPwd = inputCurrentPwd.value.trim();
    const newPwd = inputNewPwd.value.trim();
    const confirmPwd = inputConfirmPwd.value.trim();
    const hint = inputPwdHint.value.trim();

    if (newPwd.length < 4) {
      alert('Mật khẩu mới phải có tối thiểu 4 ký tự!');
      return;
    }
    if (newPwd !== confirmPwd) {
      alert('Xác nhận mật khẩu không trùng khớp!');
      return;
    }

    chrome.storage.local.get(['masterPasswordHash'], async (res) => {
      const existingHash = res.masterPasswordHash;
      if (existingHash) {
        const currentHash = await hashPassword(currentPwd);
        if (currentHash !== existingHash) {
          alert('Mật khẩu hiện tại không đúng!');
          inputCurrentPwd.focus();
          return;
        }
      }

      const newHash = await hashPassword(newPwd);
      chrome.storage.local.set({
        masterPasswordHash: newHash,
        passwordHint: hint
      }, () => {
        isUnlocked = true;
        sessionStorage.setItem('url_shield_session_unlocked', 'true');
        alert('Đã lưu mật khẩu quản trị thành công! Tiện ích hiện đã được bảo vệ.');
        inputCurrentPwd.value = '';
        inputNewPwd.value = '';
        inputConfirmPwd.value = '';
        renderData();
        switchTab('main');
      });
    });
  });

  autoLockSelect.addEventListener('change', (e) => {
    requirePassword(() => {
      chrome.storage.local.set({ autoLockSetting: e.target.value });
    }, 'thay đổi cài đặt tự động khóa');
  });

  function handleAddUrl() {
    let value = addInput.value.trim().toLowerCase();
    if (!value) return;

    requirePassword(() => {
      value = value.replace(/^(https?:\/\/)?(www\.)?/, '');
      if (!value.includes('?') && value.endsWith('/')) value = value.slice(0, -1);
      if (!value) return;

      chrome.storage.local.get(['blacklist'], (res) => {
        const blacklist = res.blacklist || [];
        if (!blacklist.includes(value)) {
          blacklist.push(value);
          chrome.storage.local.set({ blacklist }, () => {
            addInput.value = '';
            renderData();
          });
        } else {
          alert('Liên kết này đã có trong danh sách chặn!');
        }
      });
    }, 'thêm liên kết mới vào danh sách chặn');
  }

  addBtn.addEventListener('click', handleAddUrl);
  addInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleAddUrl();
  });

  blacklistContainer.addEventListener('click', (e) => {
    const deleteBtn = e.target.closest('.delete-btn');
    if (!deleteBtn) return;
    const index = parseInt(deleteBtn.dataset.index);

    requirePassword(() => {
      chrome.storage.local.get(['blacklist'], (res) => {
        const blacklist = res.blacklist || [];
        blacklist.splice(index, 1);
        chrome.storage.local.set({ blacklist }, () => {
          renderData();
        });
      });
    }, 'xóa liên kết khỏi danh sách chặn');
  });

  clearLogsBtn.addEventListener('click', () => {
    requirePassword(() => {
      if (confirm('Bạn có chắc chắn muốn xóa toàn bộ nhật ký chặn gần đây không?')) {
        chrome.storage.local.set({ blockLogs: [] }, () => {
          renderData();
        });
      }
    }, 'xóa nhật ký truy cập');
  });

  // Xuất danh sách chặn
  if (exportListBtn) {
    exportListBtn.addEventListener('click', () => {
      chrome.storage.local.get(['blacklist'], (res) => {
        const blacklist = res.blacklist || [];
        const blob = new Blob([JSON.stringify(blacklist, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'url_lock_shield_blacklist.json';
        a.click();
        URL.revokeObjectURL(url);
      });
    });
  }

  // Nhập danh sách chặn từ file
  if (importFile) {
    importFile.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;
      requirePassword(() => {
        const reader = new FileReader();
        reader.onload = (event) => {
          try {
            let imported = [];
            const text = event.target.result;
            if (file.name.endsWith('.json')) {
              imported = JSON.parse(text);
            } else {
              imported = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
            }
            if (Array.isArray(imported)) {
              chrome.storage.local.get(['blacklist'], (res) => {
                const current = res.blacklist || [];
                const merged = Array.from(new Set([...current, ...imported]));
                chrome.storage.local.set({ blacklist: merged }, () => {
                  alert(`Đã nhập thành công ${imported.length} mục vào danh sách chặn!`);
                  renderData();
                });
              });
            }
          } catch (err) {
            alert('Tệp không đúng định dạng!');
          }
        };
        reader.readAsText(file);
      }, 'nhập danh sách chặn từ tệp');
    });
  }

  renderData();
});