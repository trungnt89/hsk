// URL Lock Shield - background.js
// Quản lý chặn URL theo danh sách đen và kiểm soát an toàn

const DEFAULT_BLACKLIST = [
  "youtube.com",
  "facebook.com",
  "tiktok.com"
];

// Khởi tạo cấu hình ban đầu khi cài đặt extension
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["blacklist", "isEnabled", "blockLogs", "masterPasswordHash"], (result) => {
    if (result.blacklist === undefined) {
      chrome.storage.local.set({ blacklist: DEFAULT_BLACKLIST });
    }
    if (result.isEnabled === undefined) {
      chrome.storage.local.set({ isEnabled: true });
    }
    if (result.blockLogs === undefined) {
      chrome.storage.local.set({ blockLogs: [] });
    }
    if (result.masterPasswordHash === undefined) {
      chrome.storage.local.set({ masterPasswordHash: null });
    }
  });
});

// Hàm kiểm tra xem URL có nằm trong danh sách chặn hay không (Hỗ trợ triệt để YouTube SPA, subdomains, youtu.be, dấu gạch chéo cuối)
function isUrlBlocked(urlStr, blacklist) {
  try {
    if (!urlStr || typeof urlStr !== 'string') return false;
    const url = new URL(urlStr);
    
    // Bỏ qua các URL hệ thống nội bộ của trình duyệt
    if (
      url.protocol === "chrome:" ||
      url.protocol === "chrome-extension:" ||
      url.protocol === "about:" ||
      url.protocol === "devtools:" ||
      url.protocol === "edge:" ||
      url.protocol === "brave:"
    ) {
      return false;
    }

    const host = url.hostname.toLowerCase();
    const pathname = url.pathname.toLowerCase();
    const fullUrl = url.href.toLowerCase();

    return (blacklist || []).some(blocked => {
      let cleanBlocked = (blocked || "").trim().toLowerCase();
      if (!cleanBlocked) return false;

      // Xóa tiền tố http://, https://, www.
      cleanBlocked = cleanBlocked.replace(/^(https?:\/\/)?(www\.)?/, '');
      const cleanNoSlash = cleanBlocked.replace(/\/+$/, '');

      // 1. Nhận diện đặc biệt cho YouTube (bao gồm cả youtu.be và m.youtube.com)
      if (cleanNoSlash === 'youtube.com' || cleanNoSlash === 'm.youtube.com') {
        if (
          host === 'youtube.com' || 
          host.endsWith('.youtube.com') || 
          host === 'youtu.be' || 
          host.endsWith('.youtu.be')
        ) {
          return true;
        }
      }

      try {
        const blockedUrl = new URL("http://" + cleanBlocked);
        const blockedHost = blockedUrl.hostname;
        const blockedPath = blockedUrl.pathname;
        const blockedSearch = blockedUrl.search;

        // So khớp Hostname (chính xác hoặc là subdomain)
        const hostMatch = host === blockedHost || host.endsWith("." + blockedHost);
        if (!hostMatch) return false;

        // Nếu chặn toàn bộ domain
        if ((blockedPath === '/' || blockedPath === '') && !blockedSearch) {
          return true;
        }

        // Nếu có đường dẫn con cụ thể
        const visitedPathClean = pathname.replace(/\/+$/, '');
        const blockedPathClean = blockedPath.replace(/\/+$/, '');
        const pathMatch = visitedPathClean === blockedPathClean || visitedPathClean.startsWith(blockedPathClean + "/");
        if (!pathMatch) return false;

        // So khớp Query parameters nếu có
        if (blockedSearch) {
          const visitedParams = new URLSearchParams(url.search);
          const blockedParams = new URLSearchParams(blockedSearch);

          for (const [key, value] of blockedParams.entries()) {
            if (visitedParams.get(key) !== value) {
              return false;
            }
          }
          return true;
        }

        return true;
      } catch (err) {
        return fullUrl.includes(cleanNoSlash);
      }
    });
  } catch (e) {
    return false;
  }
}

// Ghi nhận nhật ký chặn và hiển thị thông báo với biểu tượng ổ khóa
function logBlockEvent(urlStr) {
  chrome.storage.local.get(["blockLogs"], (result) => {
    const logs = result.blockLogs || [];
    const newLog = {
      url: urlStr,
      time: new Date().toLocaleTimeString('vi-VN'),
      date: new Date().toLocaleDateString('vi-VN')
    };
    const updatedLogs = [newLog, ...logs].slice(0, 100);
    chrome.storage.local.set({ blockLogs: updatedLogs });
  });

  try {
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: "Khóa bảo vệ URL Shield",
      message: `Đã chặn truy cập trang web nằm trong danh sách cấm: ${urlStr}`,
      priority: 2
    });
  } catch (e) {
    console.warn("Lỗi tạo thông báo:", e);
  }
}

// Chuyển hướng tới trang blocked.html có biểu tượng ổ khóa
function redirectToBlocked(tabId, targetUrl) {
  logBlockEvent(targetUrl);
  const blockedPageUrl = chrome.runtime.getURL("blocked.html") + "?url=" + encodeURIComponent(targetUrl);
  chrome.tabs.update(tabId, { url: blockedPageUrl });
}

// Kiểm tra và chuyển hướng tab
function checkAndRedirect(tabId, targetUrl) {
  if (!targetUrl || targetUrl.startsWith("chrome-extension://")) return;
  chrome.storage.local.get(["blacklist", "isEnabled"], (result) => {
    const isEnabled = result.isEnabled !== false;
    const blacklist = result.blacklist || DEFAULT_BLACKLIST;

    if (isEnabled && isUrlBlocked(targetUrl, blacklist)) {
      redirectToBlocked(tabId, targetUrl);
    }
  });
}

// 1. Bắt sự kiện trước khi bắt đầu tải trang
chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId !== 0) return;
  checkAndRedirect(details.tabId, details.url);
});

// 2. Bắt sự kiện chuyển trang SPA (Single Page App - YouTube chuyển bài bằng History API)
chrome.webNavigation.onHistoryStateUpdated.addListener((details) => {
  if (details.frameId !== 0) return;
  checkAndRedirect(details.tabId, details.url);
});

// 3. Bắt sự kiện cập nhật URL của tab
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const checkUrl = changeInfo.url || (changeInfo.status === 'loading' && tab.url);
  if (checkUrl) {
    checkAndRedirect(tabId, checkUrl);
  }
});

// 4. Quét và khóa NGAY LẬP TỨC các tab đang mở khi thay đổi Blacklist hoặc bật lại Enable
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local' && (changes.blacklist || changes.isEnabled)) {
    chrome.storage.local.get(["blacklist", "isEnabled"], (res) => {
      const isEnabled = res.isEnabled !== false;
      const blacklist = res.blacklist || DEFAULT_BLACKLIST;
      if (!isEnabled) return;

      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          if (tab.id && tab.url && isUrlBlocked(tab.url, blacklist)) {
            redirectToBlocked(tab.id, tab.url);
          }
        });
      });
    });
  }
});